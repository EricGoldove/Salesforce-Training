import { LightningElement,api} from 'lwc';
import CarModelData from '@salesforce/apex/CarAppDataSoql.getData';

const getcolCars = [
    {
        label:'Car No.',fieldName:'CarUrl',type:'url',
        typeAttributes:{
            label:{
                fieldName:'Car'
            }
        }
    },
    {
        label:'Brand', fieldName:'Brand', type:'picklist'
    },
    {
        label:'Style', fieldName:'Style', type:'picklist'
    },
    {
        label:'Color', fieldName:'Color', type:'text'
    }];

const getcolCarModels = [
    {
        label:'Car Model', fieldName:'ModelUrl', type:'url',
        typeAttributes:{
            label:{
                fieldName:'Model'
            }
        }
    },
    {
        label:'Car No.', fieldName:'CarUrl', type:'url',
        typeAttributes:{
            label:{
                fieldName:'Car'
            }
        }
    },
    {
        label:'Price', fieldName:'Price', type:'currency'
    },
    {
        label:'Safety', fieldName:'Safety', type:'checkbox'
    },
    {
        label:'Quality',fieldName:'Quality', type:'checkbox'
    },
    {
        label:'Stage', fieldName:'Stage', type:'picklist'
    }];

export default class ViewCarModel extends LightningElement {    
    @api records;
	@api CarModelColumns = getcolCarModels;
	@api CarColumns = getcolCars;
	error; searchKey = '';

	handleKeys(e)
    {
        this.searchKey = e.target.value;
        this.handleCaseData();
    }

    handleCaseData()
    {
        CarModelData({'search':this.searchKey}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Model = row.Name;
                    fieldAssign.Car = row.Car__r.Name;
					fieldAssign.Price = row.Price__c;
					fieldAssign.Quality = row.Quality__c;
					fieldAssign.Safety = row.Safety__c;
					fieldAssign.Stage = row.Stage__c;
					fieldAssign.Color = row.Car__r.Car_Color__c;
					fieldAssign.Style = row.Car__r.Car_Style__c;
					fieldAssign.Brand = row.Car__r.Brand__c;
                    fieldAssign.ModelUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                    fieldAssign.CarUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car__c/'+row.Car__c.Id+'/view';
                    final.push(fieldAssign);
                })
                this.records = final;
            }
        }).catch(err => {
            this.error;
        })
    }
    
}