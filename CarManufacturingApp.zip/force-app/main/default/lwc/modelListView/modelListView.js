import { LightningElement,api,wire } from 'lwc';
import ModelData from '@salesforce/apex/CarAppDataSoql.getData';
import ifQAnalUser from '@salesforce/apex/CarAppDataSoql.ifQAnalUser';
import ifDigiMarkUser from '@salesforce/apex/CarAppDataSoql.ifDigiMarkUser';
import User from '@salesforce/apex/UserIdentification.checkUser';   

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class ModelListView extends LightningElement {
    @api getCarModelColumns = [
        { label:'Car Model', fieldName:'Name', type:'text'},    
        { label:'Car No.', fieldName:'CarNo', type:'text'},    
        { label:'Price', fieldName:'Price__c' },
        { label:'Safety', fieldName:'Safety__c', type:'boolean' },
        { label:'Quality',fieldName:'Quality__c', type:'boolean' },
        { label:'Stage', fieldName:'Stage__c', sortable: true },
        { type: 'button', typeAttributes: {  
            label: 'Edit', name: 'Edit', title: 'Edit', variant:'success'}}];
    
    showForm = false;
    showModelEditForm = false;
    btnDisable = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
        this.showModelEditForm = false;
    }

    search = ''; 
    modelRecords;
    error;
    refreshTable;
    currentUser;
    handleModelKeys(event)
    {
        this.search = event.target.value;
    }
    renderedCallback(){
        User().then(result => {
            if(result == 'Quality Analysts'){
                ifQAnalUser({search:this.search}).then(result => {
                    this.refreshTable = result;
                    this.modelRecords = result.map(row => {
                        return{...row, CarNo: row.Car__r.Name}
                    });
                }).catch(error => {
                    this.error = error;
                });
            }
            else if(result == 'Digital Marketers'){
                ifDigiMarkUser({search:this.search}).then(result => {
                    this.refreshTable = result;
                    this.btnDisable = true;
                    this.modelRecords = result.map(row => {
                        return{...row, CarNo: row.Car__r.Name}
                    });
                }).catch(error => {
                    this.error = error;
                });
            }
            else {
                ModelData({search:this.search}).then(result => {
                    this.refreshTable = result;
                    this.btnDisable = true;
                    this.modelRecords = result.map(row => {
                        return{...row, CarNo: row.Car__r.Name}
                    });
                }).catch(error => {
                    this.error = error;
                });
            }
        })
    }

    handleEdit(event){
        this.recordEditId = event.detail.row.Id;
        User().then(result => {
            if(result == 'Factory' && event.detail.row.Stage__c != 'New'){
                this.showToast('Failed', 'Car Model is already in Manufactured Stage', 'error');
            }
            else {
                this.showModelEditForm = true;
            }
        })
    }
    
    handleSuccess(){
        this.showToast('Success', 'Record Created', 'success');
        this.showForm = false;
        this.showModelEditForm = false;
        return refreshApex(this.refreshTable);
    }

    showToast(title, message, variant){
        this.dispatchEvent(
            new ShowToastEvent({
                title:title,
                message:message,
                variant:variant||'success'
            })
        )
    }
}