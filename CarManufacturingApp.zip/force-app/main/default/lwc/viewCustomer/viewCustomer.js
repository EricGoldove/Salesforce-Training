import { LightningElement,api,wire} from 'lwc';
import CarModelData from '@salesforce/apex/CarAppDataSoql.ifCustomer';

import { NavigationMixin } from 'lightning/navigation';

const getcolCars = [
    { label:'Car No.',fieldName:'Car',type:'text'},
    { label:'Brand', fieldName:'Brand__c', type:'picklist'},
    { label:'Style', fieldName:'Car_Style__c', type:'picklist'},
    { label:'Color', fieldName:'Car_Color__c', type:'text'}];

const getcolCarModels = [
    { label:'Car Model', fieldName:'Model', type:'text'},
    { label:'Car No.', fieldName:'Car', type:'text'},
    { label:'Price', fieldName:'Price__c', type:'currency'},
    { label:'Safety', fieldName:'Safety__c', type:'checkbox'},
    { label:'Quality',fieldName:'Quality__c', type:'checkbox'},
    { label:'Stage', fieldName:'Stage__c', type:'picklist'},
    {type: 'button', typeAttributes: {  
        label: 'Buy', name: 'add', title: 'add', variant:'brand'}}];

export default class ViewCarModel extends NavigationMixin(LightningElement) {    
    @api records;
	@api CarModelColumns = getcolCarModels;
	@api CarColumns = getcolCars;
	error; searchKey = '';
    refreshTable;

	handleKeys(e)
    {
        this.searchKey = e.target.value;
    }
    @wire(CarModelData,{search : '$searchKey'})
    getCarData(result){
        this.refreshTable = result;
        if(result.data){
            this.records = result.data.map(row => {
                return {...row,Car:row.Car__r.Name,Model:row.Name}
            })
        }
        else{
            this.error = result.error;
        }
    }
    
    getSelectedCar(event){
        const carModel = event.detail.row.Name;
        const price = event.detail.row.Price__c;
        console.log(carModel);
    }
}