import { LightningElement,wire, api } from 'lwc';
import LeadData from '@salesforce/apex/CarAppDataSoql.getLeadData';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class ContactListView extends LightningElement {
    @api getLeadColumns = [
        { label:'Lead', fieldName:'Name', type:'text'},
        { label:'Company', fieldName:'Company', },
        { label:'Phone', fieldName:'Phone', type:'phone' },
        { label:'Email', fieldName:'Email', type:'email' },
        { label:'Status', fieldName:'Status' }]

    showForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
    }

    searchLead = '';
    leadRecords;
    refreshTable;
    handleLeadKeys(event)
    {
        this.searchLead = event.target.value;
    }
    @wire(LeadData, {search:'$searchLead'})
    getLeadData(result){
        if(result.data){
            this.refreshTable = result.data;
            this.leadRecords = result.data;
            this.error=undefined;
        }
        else{
            this.error = result.error;
            this.leadRecords=undefined;
        }
    }

    renderedCallback(){
        refreshApex(this.refreshTable);
    }

    handleSuccess(){
        this.showForm = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title:'Success',
                message:'Lead Created',
                variant:'success'
            })
        )
        refreshApex(this.refreshTable);
    }
}