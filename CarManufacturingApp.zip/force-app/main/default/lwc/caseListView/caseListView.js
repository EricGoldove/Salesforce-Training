import { LightningElement, api, wire } from 'lwc';
import CaseData from '@salesforce/apex/CarAppDataSoql.getCaseData';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class CaseListView extends LightningElement {
    @api getCaseColumns = [
        { label:'Cases', fieldName:'CaseUrl', type:'url', 
        typeAttributes: {
            label: { fieldName: 'CaseNumber' },}},
        { label:'Accounts', fieldName:'AccountUrl', type:'url', 
        typeAttributes: {
            label: { fieldName: 'Account' },}},
        { label:'Contacts', fieldName:'ContactUrl', type:'url', 
        typeAttributes: {
            label: { fieldName: 'Contact' },}},
        { label:'Subject', fieldName:'Subject', },
    ]

    showForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
    }

    searchCase = '';
    caseRecords;
    refreshTable;
    handleCaseKeys(event)
    {
        this.searchCase = event.target.value;
        this.handleCaseData();
    }
    handleCaseData()
    {
        CaseData({'search':this.searchCase}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.CaseNumber = row.CaseNumber;
                    fieldAssign.Subject = row.Subject;
                    fieldAssign.Account = row.Account.Name;
                    fieldAssign.Contact = row.Contact.Name;
                    fieldAssign.ContactUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Contact/'+row.ContactId+'/view';
                    fieldAssign.AccountUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.AccountId+'/view';
                    fieldAssign.CaseUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Case/'+row.Id+'/view';
                    final.push(fieldAssign);
                })
                this.caseRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    handleSuccess(){
        this.showForm = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title:'Success',
                message:'Case Created',
                variant:'success'
            })
        )
        refreshApex(this.refreshTable);
    }
}