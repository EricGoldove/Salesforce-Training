import { LightningElement } from 'lwc';
import User from '@salesforce/apex/UserIdentification.checkUser';   

export default class CarAppTabset extends LightningElement {
    showCar = false;
    showModel = false;
    showBooking = false;
    showAccount = false;
    showContact = false;
    showLead = false;
    showCase = false;
    showCampaign =false;

    connectedCallback(){
        User().then(result => {
            if(result == 'Company Executives'){
                this.showCar = true;
            }else if(result == 'Factory'){
                this.showModel = true;
            }else if(result == 'Quality Analysts'){
                this.showModel = true;
            }else if(result == 'Digital Marketers'){
                this.showModel = true;
                this.showCampaign = true;
            }else if(result == 'Sales Executives'){
                this.showModel = true;
            }else if(result == 'Sales User'){
                this.showAccount = true;
                this.showContact = true;
                this.showLead = true;
            }else if(result == 'Customer Service Representatives'){
                this.showCase = true;
            }else{
                this.showCar = true;
                this.showModel = true;
                this.showBooking = true;
                this.showAccount = true;
                this.showContact = true;
                this.showLead = true;
                this.showCase = true;
                this.showCampaign =true;
            }
        })
    }
}