import { LightningElement,wire, api } from 'lwc';
import ContactData from '@salesforce/apex/CarAppDataSoql.getContactData';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class ContactListView extends LightningElement {
    @api getContactColumns = [
        { label:'Contact', fieldName:'ContactUrl', type:'url', 
        typeAttributes: {
            label: { fieldName: 'Contact' },}},
        { label:'Account', fieldName:'AccountUrl', type:'url', 
        typeAttributes: {
            label: { fieldName: 'Account' },}},
        { label:'Phone', fieldName:'Phone',type:'phone' },
        { label:'Email', fieldName:'Email', type:'email' }
    ]

    showForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
    }

    searchContact = '';
    contactRecords;
    refreshTable;
    handleContactKeys(event)
    {
        this.searchContact = event.target.value;
        this.handleContactData();
    }
    handleContactData()
    {
        ContactData({'search':this.searchContact}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Contact = row.Name;
                    fieldAssign.Account = row.Account.Name;
                    fieldAssign.Phone = row.Phone;
                    fieldAssign.Email = row.Email;
                    fieldAssign.ContactUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Id+'/view';
                    fieldAssign.AccountUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account.Id+'/view';
                    final.push(fieldAssign);
                })
                this.contactRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    handleSuccess(){
        this.showForm = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title:'Success',
                message:'Contact Created',
                variant:'success'
            })
        )
        refreshApex(this.refreshTable);
    }
}