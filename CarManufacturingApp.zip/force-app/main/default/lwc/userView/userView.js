import { LightningElement, wire, track, api } from 'lwc';
import deleteSelectedCar from '@salesforce/apex/CarAppDataSoql.deleteSelectedCar';
import ModelData from '@salesforce/apex/CarAppDataSoql.getData';
import CarData from '@salesforce/apex/CarAppDataSoql.getCarAppData';
import BookingData from '@salesforce/apex/CarAppDataSoql.getBookingAppData';
import AccountData from '@salesforce/apex/CarAppDataSoql.getAccountData';
import ContactData from '@salesforce/apex/CarAppDataSoql.getContactData';
import LeadData from '@salesforce/apex/CarAppDataSoql.getLeadData';
import CaseData from '@salesforce/apex/CarAppDataSoql.getCaseData';
import CampaignData from '@salesforce/apex/CarAppDataSoql.getCampaignData';
import User from '@salesforce/apex/UserIdentification.checkUser';   

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

const getCarColumns = [
    { label:'Car No.', fieldName:'Name', type:'text', },
    { label:'Brand', fieldName:'Brand__c' },
    { label:'Style', fieldName:'Car_Style__c'},
    { label:'Color', fieldName:'Car_Color__c'}];

const getCarModelColumns = [
    { label:'Car Model', fieldName:'ModelUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Model' },}},

    { label:'Car No.', fieldName:'CarUrl2', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Car2' },}},

    { label:'Price', fieldName:'Price' },
    { label:'Safety', fieldName:'Safety', type:'boolean' },
    { label:'Quality',fieldName:'Quality', type:'boolean' },
    { label:'Stage', fieldName:'Stage' }];

const getCarBookingColumns = [
    { label:'Booking ID', fieldName:'BookUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'BookingID' },}},

    { label:'Model Name', fieldName:'ModelNameUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'ModelName' },}},
        
    { label:'Account Name', fieldName:'AccUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Account' },}},

    { label:'Price', fieldName:'Price',type:'currency' },
    { label:'Paid', fieldName:'Paid', type:'boolean' },
    { label:'Status',fieldName:'Status', type:'boolean'},
    { label:'Assigned', fieldName:'Assigned', type:'boolean'  },
    { label:'Date Delivered', fieldName:'DateDelivered', type:'date'}];

const getAccountColumns = [
    { label:'Account', fieldName:'AccountUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Account' },}},
    { label:'Phone', fieldName:'Phone',type:'phone' },
    { label:'Industry', fieldName:'Industry' },
    { label:'Type',fieldName:'Type' }
]

const getContactColumns = [
    { label:'Contact', fieldName:'ContactUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Contact' },}},
    { label:'Account', fieldName:'AccountUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Account' },}},
    { label:'Phone', fieldName:'Phone',type:'phone' },
    { label:'Email', fieldName:'Email', type:'email' }
]

const getLeadColumns = [
    { label:'Lead', fieldName:'LeadUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Lead' },}},
    { label:'Company', fieldName:'Company', },
    { label:'Phone', fieldName:'Phone', type:'phone' },
    { label:'Email', fieldName:'Email', type:'email' },
    { label:'Status', fieldName:'Status' }
]

const getCaseColumns = [
    { label:'Cases', fieldName:'CaseUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'CaseNumber' },}},
    { label:'Accounts', fieldName:'AccountUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Account' },}},
    { label:'Contacts', fieldName:'ContactUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Contact' },}},
    { label:'Subject', fieldName:'Subject', },
]

const getCampaignColumns = [
    { label:'Campaign', fieldName:'CampaignUrl', type:'url', 
    typeAttributes: {
        label: { fieldName: 'Campaign' },}},
    { label:'Start Date', fieldName:'StartDate', type:'date' },
    { label:'End Date', fieldName:'EndDate', type:'date' },
    { label:'Budgeted Cost', fieldName:'BudgetedCost', type:'currency' },
    { label:'Actual Cost', fieldName:'ActualCost', type:'currency' },
    { label:'Type', fieldName:'Type', type:'picklist' },
    { label:'Status', fieldName:'Status', type:'picklist' }
]
export default class UserView extends LightningElement {
showCar = false;
showModel = false;
showBooking = false;
showAccount = false;
showContact = false;
showLead = false;
showCase = false;
showCampaign =false;

showCarForm = false;
showCarEditForm = false;
showCarModelForm = false;
showCarEditModelForm = false
showAccountForm = false;
showContactForm = false;
showLeadForm = false;
showCampaignForm = false;
currentUser;



connectedCallback(){
    User().then(result => {
        if(result == 'Company Executives'){
            this.showCar = true;
            this.showCarForm = true;
        }else if(result == 'Factory'){
            this.showModel = true;
            this.showCarModelForm = true;
        }else if(result == 'Quality Analysts'){
            this.showCarModelForm = false;
            this.showModel = true;
        }else if(result == 'Digital Marketers'){
            this.showModel = true;
            this.showCampaign = true;
            this.showCampaignForm = true;
        }else if(result == 'Sales Executives'){
            this.showModel = true;
        }else if(result == 'Sales User'){
            this.showAccount = true;
            this.showContact = true;
            this.showLead = true;
            this.showAccountForm = true;
            this.showContactForm = true;
            this.showLeadForm = true;
        }else if(result == 'Customer Service Representatives'){
            this.showCampaign = true;
        }else{
            this.showCar = true;
            this.showModel = true;
            this.showBooking = true;
            this.showAccount = true;
            this.showContact = true;
            this.showLead = true;
            this.showCase = true;
            this.showCampaign =true;
            this.showCarForm = true;
            this.showAccountForm = true;
            this.showContactForm = true;
            this.showLeadForm = true;
            this.showCarModelForm = true;
        }
    })
}

    searchCar = '';
    @track carRecords; 
    @track CarColumns = getCarColumns;
    @track error; 
    @track buttonLabel = 'Delete Records';
    @track isTrue = false;
    refreshTable;
    selectedRecords = [];
    handleCarKeys(e)
    {
         this.searchCar = e.target.value;
    }
    @wire(CarData,{search : '$searchCar'})
    getCarData(result){
        this.refreshTable = result;
        if(result.data){
            this.carRecords = result.data;
        }
        else{
            this.error = result.error;
        }
    }
    @track recordCarId;
    recordsCount = 0;
    getSelectedCar(event) {
        const selectedRows = event.detail.selectedRows;
        this.recordsCount = event.detail.selectedRows.length;
        this.recordCarId = selectedRows[0].Id;
        this.selectedRecords = new Array();
        for (let i = 0; i < selectedRows.length; i++) {
            this.selectedRecords.push(selectedRows[i]);
        }   
        window.console.table(selectedRows[0]);
        this.showCarEditForm = true;
    }
    handleSuccess(){
        return refreshApex(this.refreshTable);
    }
    handleDelete(){
        if (this.selectedRecords) {
            this.buttonLabel = 'Processing....';
            this.isTrue = true;
            deleteSelectedCar({carLst: this.selectedRecords }).then(result => {
                window.console.log('result ====> ' + result);
                this.buttonLabel = 'Delete Records';
                this.isTrue = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success!!',
                        message: this.recordsCount + ' records are deleted.',
                        variant: 'success'
                    }),
                );
                this.template.querySelector('lightning-datatable').selectedRows = [];
                this.recordsCount = 0;
                return refreshApex(this.refreshTable);
            }).catch(error => {
                this.buttonLabel = 'Delete Records';
                this.isTrue = false;                
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error while getting Contacts',
                        message: JSON.stringify(error),
                        variant: 'error'
                    }),
                );
            });
        }
    }

    search = ''; 
    @track modelRecords;
    @track CarModelColumns = getCarModelColumns;
    @track error;
    handleModelKeys(e)
    {
        this.search = e.target.value;
        this.handleModelData();
    }
    handleModelData()
    {
        ModelData({'search':this.search}).then( res =>{
            if(res) {
                User().then(curUser => {
                    let final=[];
                    res.forEach(row =>{
                        if((curUser == 'Quality Analysts' && row.Stage__c == 'Manufactured') || 
                           (curUser == 'Digital Marketers' && row.Stage__c != 'Manufactured') ||
                           (curUser == 'Sales Executives' && row.Stage__c == 'Ready to Launch')){
                            console.log(curUser + ' ' + row.Stage__c)
                            let fieldAssign = {};
                            fieldAssign.Id = row.Id;
                            fieldAssign.Model = row.Name;
                            fieldAssign.Car2 = row.Car__r.Name;
                            fieldAssign.Price = row.Price__c;
                            fieldAssign.Quality = row.Quality__c;
                            fieldAssign.Safety = row.Safety__c;
                            fieldAssign.Stage = row.Stage__c;
                            fieldAssign.ModelUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            fieldAssign.CarUrl2 ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car__c/'+row.Car__r.Id+'/view';
                            final.push(fieldAssign);
                        } else if(curUser == 'Company Executives' || curUser == 'Factory' || curUser == 'System Administrator'){
                            let fieldAssign = {};
                            fieldAssign.Id = row.Id;
                            fieldAssign.Model = row.Name;
                            fieldAssign.Car2 = row.Car__r.Name;
                            fieldAssign.Price = row.Price__c;
                            fieldAssign.Quality = row.Quality__c;
                            fieldAssign.Safety = row.Safety__c;
                            fieldAssign.Stage = row.Stage__c;
                            fieldAssign.ModelUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Id+'/view';
                            fieldAssign.CarUrl2 ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car__c/'+row.Car__r.Id+'/view';
                            final.push(fieldAssign);
                        }
                    })
                    this.modelRecords = final;
                })                
            }
        }).catch(err => {
            this.error = err;
        })
    }
    recordModelId;
    safety; quality;
    haltQA = false;
    haltFE = false;
    getSelectedModel(event) {
        const selectedRows = event.detail.selectedRows;
        this.selectedRows = selectedRows;
        this.recordModelId = selectedRows[0].Id;
        this.safety = selectedRows[0].Safety;
        this.quality = selectedRows[0].Quality;
        this.showCarEditModelForm = true;   
        User().then(curUser => {
            if(curUser == 'Factory' && this.selectedRows[0].Stage != 'New'){
                this.haltFE = true;
            } 
            else if(curUser == 'Quality Analysts' && selectedRows[0].Safety == false && selectedRows[0].Quality == false){
                this.haltQA = true;
            }
        })      
    }
    handleSubmit(event){     
        if(this.haltFE == true){
            event.preventDefault();
            alert('It\'s currently/passed Manufactured Stage');
        } else if(this.haltQA == true){
            event.preventDefault();
            alert('Safety and Quality hasn\'t passed yet!');
        }
    }
    
    searchBook = '';
    bookingRecords;
    CarBookingColumns = getCarBookingColumns;
    handleBookingKeys(c)
    {
        this.searchBook = c.target.value;
        this.handleBookingData();
    }
    handleBookingData()
    {
        BookingData({'search':this.searchBook}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.BookingID = row.Name;
                    fieldAssign.ModelName = row.Car_Model__r.Name;
                    fieldAssign.Account = row.Account__r.Name;
                    fieldAssign.Price = row.Price__c;
                    fieldAssign.Paid = row.Paid__c;
                    fieldAssign.Status = row.Status__c;
                    fieldAssign.Assigned = row.Assigned__c;
                    fieldAssign.DateDelivered = row.Date_Delivered__c;
                    fieldAssign.BookUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car_Booking__c/'+row.Id+'/view';
                    fieldAssign.ModelNameUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Car_Model__c/'+row.Car_Model__r.Id+'/view';
                    fieldAssign.AccUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account__r.Id+'/view';
                    final.push(fieldAssign);
                })
                this.bookingRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    searchAcc = '';
    accountRecords;
    accountColumns = getAccountColumns;
    handleAccountKeys(c)
    {
        this.searchAcc = c.target.value;
        this.handleAccountData();
    }
    handleAccountData()
    {
        AccountData({'search':this.searchAcc}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Account = row.Name;
                    fieldAssign.Phone = row.Phone;
                    fieldAssign.Industry = row.Industry;
                    fieldAssign.Type = row.Type;
                    fieldAssign.AccountUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.Id+'/view';
                    final.push(fieldAssign);
                })
                this.accountRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    searchCon = '';
    contactRecords;
    contactColumns = getContactColumns;
    handleContactKeys(d)
    {
        this.searchCon = d.target.value;
        this.handleContactData();
    }
    handleContactData()
    {
        ContactData({'search':this.searchCon}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Contact = row.Name;
                    fieldAssign.Account = row.Account.Name;
                    fieldAssign.Phone = row.Phone;
                    fieldAssign.Email = row.Email;
                    fieldAssign.ContactUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Id+'/view';
                    fieldAssign.AccountUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.Account.Id+'/view';
                    final.push(fieldAssign);
                })
                this.contactRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    searchLead = '';
    leadRecords;
    leadColumns = getLeadColumns;
    handleLeadKeys(d)
    {
        this.searchLead = d.target.value;
        this.handleLeadData();
    }
    handleLeadData()
    {
        LeadData({'search':this.searchLead}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Lead = row.Name;
                    fieldAssign.Company = row.Company;
                    fieldAssign.Phone = row.Phone;
                    fieldAssign.Email = row.Email;
                    fieldAssign.Status = row.Status;
                    fieldAssign.LeadUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Lead/'+row.Id+'/view';
                    final.push(fieldAssign);
                })
                this.leadRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    searchCase = '';
    caseRecords;
    caseColumns = getCaseColumns;
    handleCaseKeys(e)
    {
        this.searchCase = e.target.value;
        this.handleCaseData();
    }
    handleCaseData()
    {
        CaseData({'search':this.searchCase}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.CaseNumber = row.CaseNumber;
                    fieldAssign.Subject = row.Subject;
                    fieldAssign.Account = row.Account.Name;
                    fieldAssign.Contact = row.Contact.Name;
                    fieldAssign.ContactUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Contact/'+row.ContactId+'/view';
                    fieldAssign.AccountUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Account/'+row.AccountId+'/view';
                    fieldAssign.CaseUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Case/'+row.Id+'/view';
                    final.push(fieldAssign);
                })
                this.caseRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

    searchCampaign = '';
    campaignRecords;
    campaignColumns = getCampaignColumns;
    handleCampaignKeys(e)
    {
        this.searchCampaign = e.target.value;
        this.handleCampaignData();
    }
    handleCampaignData()
    {
        CampaignData({'search':this.searchCampaign}).then( res =>{
            if(res)
            {
                let final=[];
                res.forEach(row =>{
                    let fieldAssign = {};
                    fieldAssign.Id = row.Id;
                    fieldAssign.Campaign = row.Name;
                    fieldAssign.BudgetedCost = row.BudgetedCost;
                    fieldAssign.StartDate = row.StartDate;
                    fieldAssign.EndDate = row.EndDate;
                    fieldAssign.ActualCost = row.ActualCost;
                    fieldAssign.Type = row.Type;
                    fieldAssign.Status = row.Status;
                    fieldAssign.CampaignUrl ='https://trailhead427-dev-ed.lightning.force.com/lightning/r/Campaign/'+row.Id+'/view';
                    final.push(fieldAssign);
                })
                this.campaignRecords = final;
            }
        }).catch(err => {
            this.error;
        })
    }

}