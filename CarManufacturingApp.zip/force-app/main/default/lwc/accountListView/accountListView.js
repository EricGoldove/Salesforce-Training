import { LightningElement, api, wire } from 'lwc';
import AccountData from '@salesforce/apex/CarAppDataSoql.getAccountData';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class AccountListView extends LightningElement {
    @api getAccountColumns = [
        { label:'Account', fieldName:'Name', type:'text'},
        { label:'Phone', fieldName:'Phone',type:'phone' },
        { label:'Industry', fieldName:'Industry' },
        { label:'Type',fieldName:'Type' }
    ];
    
    showForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
    }

    searchAccount = '';
    accountRecords;
    handleAccountKeys(event)
    {
        this.searchAccount = event.target.value;
    }
    @wire(AccountData, {search:'$searchAccount'})
    getAccountData(result){
        if(result.data){
            this.refreshTable = result.data;
            this.accountRecords = result.data;
            this.error=undefined;
        }
        else{
            this.error = result.error;
            this.accountRecords=undefined;
        }
    }

    renderedCallback(){
        refreshApex(this.refreshTable);
    }

    handleSuccess(){
        this.showForm = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title:'Success',
                message:'Account Created',
                variant:'success'
            })
        )
        refreshApex(this.refreshTable);
    }
}