import { LightningElement,api,wire } from 'lwc';
import CarData from '@salesforce/apex/CarAppDataSoql.getCarAppData';
import deleteSelectedCar from '@salesforce/apex/CarAppDataSoql.deleteSelectedCar';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';

export default class CarListView extends LightningElement {
    @api getCarColumns = [
        { label:'Car No.', fieldName:'Name', type:'text', },
        { label:'Brand', fieldName:'Brand__c' },
        { label:'Style', fieldName:'Car_Style__c'},
        { label:'Color', fieldName:'Car_Color__c'},
        { type: 'button', typeAttributes: {  
            label: 'Edit', name: 'Edit', title: 'Edit', variant:'success'}}];

    showForm = false;
    showCarEditForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
        this.showCarEditForm = false;
    }

    searchCar = '';
    @api carRecords; 
    @api error; 
    @api buttonLabel = 'Delete Records';
    @api isTrue = false;
    refreshTable;
    selectedRecords = [];
    handleCarKeys(e)
    {
            this.searchCar = e.target.value;
    }
    @wire(CarData,{search : '$searchCar'})
    getCarData(result){
        this.refreshTable = result;
        if(result.data){
            this.carRecords = result.data;
        }
        else{
            this.error = result.error;
        }
    }
    recordCarId;
    recordsCount = 0;
    recordEditId
    handleEdit(event){
        this.recordEditId = event.detail.row.Id;
        console.log(this.recordEditId)
        this.showCarEditForm = true;
    }
    async getSelectedCar(event) {
        const selectedRows = event.detail.selectedRows;
        this.recordsCount = event.detail.selectedRows.length;
        this.recordCarId = selectedRows[0].Id;
        this.selectedRecords = new Array();
        for (let i = 0; i < selectedRows.length; i++) {
            this.selectedRecords.push(selectedRows[i]);
        }   
        window.console.table(selectedRows[0]);
    }
    handleDelete(){
        if (this.selectedRecords) {
            this.buttonLabel = 'Processing....';
            this.isTrue = true;
            deleteSelectedCar({carLst: this.selectedRecords }).then(result => {
                window.console.log('result ====> ' + result);
                this.buttonLabel = 'Delete Records';
                this.isTrue = false;
                this.showToast('Succress!!', this.recordsCount + ' records are deleted.', 'success');
                
                this.template.querySelector('lightning-datatable').selectedRows = [];
                this.recordsCount = 0;
                return refreshApex(this.refreshTable);
            }).catch(error => {
                this.buttonLabel = 'Delete Records';
                this.isTrue = false;                
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error while getting Contacts',
                        message: JSON.stringify(error),
                        variant: 'error'
                    }),
                );
            });
        }
    }
    
    handleSuccess(){
        this.showToast('Success', 'Record Created', 'success');
        this.showForm = false;
        this.showCarEditForm = false;
        return refreshApex(this.refreshTable);
    }
    showToast(title, message, variant){
        this.dispatchEvent(
            new ShowToastEvent({
                title:title,
                message:message,
                variant:variant||'success'
            })
        )
    }
}