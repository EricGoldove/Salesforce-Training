import { LightningElement, api, wire } from 'lwc';
import CampaignData from '@salesforce/apex/CarAppDataSoql.getCampaignData';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
export default class CampaignListView extends LightningElement {
    @api getCampaignColumns = [
        { label:'Campaign', fieldName:'Name', type:'text'},
        { label:'Start Date', fieldName:'StartDate', type:'date' },
        { label:'End Date', fieldName:'EndDate', type:'date' },
        { label:'Budgeted Cost', fieldName:'BudgetedCost', type:'currency' },
        { label:'Actual Cost', fieldName:'ActualCost', type:'currency' },
        { label:'Type', fieldName:'Type', type:'picklist' },
        { label:'Status', fieldName:'Status', type:'picklist' },
        { label:'Subject', fieldName:'Subject', type:'text' }
    ];

    showForm = false;
    openForm(){
        this.showForm = true;
    }
    closeForm(){
        this.showForm = false;
    }

    searchCampaign = '';
    campaignRecords;
    handleCampaignKeys(event)
    {
        this.searchCampaign = event.target.value;
    }
    @wire(CampaignData, {search:'$searchCampaign'})
    getCampaignData(result){
        if(result.data){
            this.refreshTable = result.data;
            this.campaignRecords = result.data;
            this.error=undefined;
        }
        else{
            this.error = result.error;
            this.campaignRecords=undefined;
        }
    }

    renderedCallback(){
        refreshApex(this.refreshTable);
    }

    handleSuccess(){
        this.showForm = false;
        this.dispatchEvent(
            new ShowToastEvent({
                title:'Success',
                message:'Campaign Created',
                variant:'success'
            })
        )
        refreshApex(this.refreshTable);
    }
}